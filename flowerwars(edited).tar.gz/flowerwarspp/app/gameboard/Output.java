package app.gameboard;
import flowerwarspp.preset.*;
import app.superflowerwars64.*;
/**
 * Die Schnittstellle Output enthält die Methoden, die man für
 * eine einfache graphische Ausgabe braucht
 * @author Viktoriya Pak
 */
public interface Output {
	/**
	 * Setzt ein {@link MyViewer}-Objekt
	 * @param myViewer {@link MyViewer}
	 */
	void setMyViewer(MyViewer myViewer);
	/**
     * Fördert die Bearbeitung und graphische Ausgabe des zuletzt gemachten Zuges
     * @param lastMove Der Spielzug, der zuletzt gemacht wurde
     */
	void display(Move lastMove);
}
