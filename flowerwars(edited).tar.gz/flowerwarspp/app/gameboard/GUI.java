package app.gameboard;
import flowerwarspp.preset.*;
import app.superflowerwars64.*;
import java.awt.*;
import javax.swing.*;
import java.io.*;
import java.util.*;
import java.lang.*;
/**
    * Die Klasse GUI mdeldet, dass ein Spielbrett Ereigniss
    * bearbeitet werden soll sowie erzeugt das Brett selbst
    * @author Viktoriya Pak
 */
public class GUI implements Requestable, Output {
    /**
     * Das Spielbrett
     */
    private GameboardGUI gameboard;
    /**
     * Enthält alle Informationen zum aktuellen Zustand eines Spielbretts
     */
    private MyViewer myViewer;
    /**
     * Bestimmt, ob die Eingabe durch GUI oder nicht
     */
    public boolean isGUI;
    /**
     * Serialisierungskonstante
     */
    private static final long serialVersionUID = 1L;

    /**
     * Konstruktor der Klasse. Erzeugt Frame, Panel für das Spielbrett,
     * Scores-Tabelle und Buttons
     * @param myViewer {@link #myViewer}
     * @param isGUI    {@link #isGUI}
     */
    public GUI(MyViewer myViewer,boolean isGUI) {
        this.myViewer = myViewer;
        this.isGUI = isGUI;
        JFrame f = new JFrame("SuperFlowerWars64");
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setSize(1280, 1080);
        gameboard = new GameboardGUI(f, myViewer.getSize(), this);
        gameboard.setMyViewer(myViewer);
        JPanel scores = new Scores();
        gameboard.add(scores);
        gameboard.add(new Buttons(gameboard));
        gameboard.setBackground(new Color(255,140,0));
        scores.setBackground(new Color(255,140,0));
        f.add(gameboard);
        f.setVisible(true);
    }
    /**
     * Fördert einen Spielzug und liefert ihn zurück
     * @return Spielzug als {@link Move}-Objekt
     */
    @Override
    public synchronized Move request() {
      return gameboard.getNewMove();
    }
    /**
     * Fördert die Bearbeitung und graphische Ausgabe des zuletzt gemachten Zuges
     * @param lastMove Der Spielzug, der zuletzt gemacht wurde
     */
    @Override
    public void display(Move lastMove) {
        gameboard.handleLastMove(lastMove);
    }
    /**
     * Setter-Methode für {@link #myViewer}
     * @param viwer [description]
     */
    @Override
    public void setMyViewer(MyViewer viwer){
      myViewer = viwer;
    }
    /**
     * Aktualisiert {@link #myViewer} sowie fördert Punktenaktualisierung
     * und prüft, ob das Spiel beendet ist. 
     * @param viewer [description]
     */
    public void update(MyViewer viewer){
      myViewer=viewer;
      gameboard.setMyViewer(viewer);
      gameboard.paintScores();
      gameboard.isEnd();
    }

}
