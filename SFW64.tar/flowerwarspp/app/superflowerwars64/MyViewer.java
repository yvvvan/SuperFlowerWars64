package app.superflowerwars64;
import flowerwarspp.preset.*;
import java.util.*;
import app.superflowerwars64.SWRBoard;

/**
 * Klasse, die das Status von Spiel-Brett ausliefern kann
 */
 public class MyViewer implements Viewer {
   /**Spiel-Brett*/
   private SWRBoard gameboard;
   /**der nächste Spieler*/
   private PlayerColor turnColor;
   /**das Status vom Brett*/
   private Status state;
//==============================================================================
   /**
    * [MyViewer Konstruktor]
    * @param gameboard [Spiel-Brett]
    * @param turnColor [SpielerFarber]
    * @param state     [description]
    */
   public MyViewer(SWRBoard gameboard,
                    PlayerColor turnColor,
                    Status state) {
     this.gameboard = gameboard;
     this.turnColor = turnColor;
     this.state = state;
   }
//==============================================================================
   public PlayerColor getTurn() {
     return turnColor;
   }

   public int getSize() {
     return gameboard.getSize();
   }

   public Status getStatus() {
     return gameboard.getStatus();
   }

   public Collection<Flower> getFlowers(final PlayerColor color) {
     return gameboard.getFlowers(color);
   }

   public Collection<Ditch> getDitches(final PlayerColor color) {
     return gameboard.getDitches(color);
   }

   public Collection<Move> getPossibleMoves() {
     return gameboard.getPossibleMoves();
   }

   public int getPoints(final PlayerColor color) {
     return gameboard.getPoints(color);
   }

   public Collection<Move> getPossibleMovesFl() {
     return gameboard.getPossibleMovesFl();
   }

   public Collection<Move> getPossibleMovesDi() {
     return gameboard.getPossibleMovesDi();
   }

 }
