package app.superflowerwars64;

import app.player.*;
import app.gameboard.*;
import flowerwarspp.preset.*;
import java.net.*;
import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;
import java.util.*;

/**
 * main class
 * !!!!!!!!!!!!! Eingabe: Einleitung !!!!!!!!!!
 * Nomal Spiel:               -red tt -blue tt -size xx (--gui) (-delay xx)
 * Remote Offer:   entweder   -red remote -typRemote tt -size xx --offer        oder    -blue remote -typRemote tt -size xx --offer
 * Remote Finder:  entweder   -blue remote -typRemote tt -size xx               oder    -red remote -typRemote tt -size xx
 * 1. tt kann nur (human,random oder adv1) seinen
 * 2. xx sollte int-Zahl sein
 * 3. wenn Offer ein HumanSpieler ist, -size ist nötig, sonst ist auch optional
 * 4. () ist eine optional-Eingabe: (--gui) bietet GUI-eingabe wenn es Human-spiler gibt
 */
public class SFW64 {
  /**main-Board*/
  private SWRBoard board;
  /**Spiel 1 -> Rot-Spieler*/
  private Player player1;
  /**Spiel 2 -> Blau-Spieler*/
  private Player player2;
  /**Eingabe Methode: entweder GUI oder Terminal*/
  private Eingabe eingabe = new Eingabe();
  /**ArgsParser wird Parameter speichern, wie PlayerType, SIZE, isOffer ...*/
  private ArgumentParser ArgsParser;
  /**GUI graphical user interface*/
	private GUI gui=null;
  /**die Groesse des Bretts*/
  private int SIZE;
  /**Delay für Spieler 1, wenn HUMAN-Spiler : immer 0*/
  private int DELAY1=0;
  /**Delay für Spieler 2, wenn HUMAN-Spiler : immer 0*/
  private int DELAY2=0;
  /**jeder Zug wird ausgedruck, wenn true*/
  private boolean debug = false;

//===================================================================================
/**
 * [main Main-Methode vom ganzen Spiel. Es wird zuerst Initialisieren,dann Operate(Laufen)]
 * @param  args                    [eingegeben Parameter]
 * @throws ArgumentParserException [Parameter nicht richtig eingegeben]
 */
  public static void main (String[] args) throws ArgumentParserException{
    SFW64 flowerwar=new SFW64();
    flowerwar.init(args);
    //wenn das nicht Offer ist, also wenn es "hosting the game", wird weiter operate()
    //sonst , liefert einfach ein Spieler aus.
    if(!flowerwar.ArgsParser.isOffer()){
      flowerwar.operate();
    }
    // else {flowerwar.operate();}
  }

//===================================================================================
/**
 * [init Initialisierung des Spiels]
 * @param  args                    [eingegeben Parameter]
 * @throws ArgumentParserException [Parameter nicht richtig eingegeben]
 */
  public void init(String[] args) throws ArgumentParserException{

    ArgsParser = new ArgumentParser(args);
    debug = ArgsParser.isDebug();

if(!ArgsParser.isOffer()){
      SIZE = ArgsParser.getSize();
      //mit GUI EINGABE ODER NICHT
      boolean isGUI = ArgsParser.isGUI();

      board = new SWRBoard (SIZE);

      gui = new GUI(board.viewer(),isGUI);
      gui.update(board.viewer());

      eingabe.setGui(gui);

      setPlayer(eingabe,ArgsParser);

    }else offering(eingabe,ArgsParser);
  }

//===================================================================================
/**
 * [setPlayer zwei Spiler-Object werden hier erzeugt]
 * @param  eingabe                 [eingabe-Methode,die von HUMAN-Spieler genutzt wird]
 * @param  Args                    [ArgumentParser, der alle Parameter gespeichert hat]
 * @throws ArgumentParserException [Parameter nicht richtig eingegeben]
 */
  public void setPlayer(Eingabe eingabe, ArgumentParser Args)throws ArgumentParserException {
    Player[] p = new Player[2];
    int[] Delay = new int[2];

    PlayerType[] type = new PlayerType[]{null,null};
    try{
      type[0] = Args.getRed();
    }catch (Exception e){} //falls Leer heisst Remote-Spieler
    try{
      type[1] = Args.getBlue();
    }catch (Exception e){}

    for(int i = 0; i < 2; i++){
      if(type[i]!=null){ //falls null -> i++ -> case: Remote -> 2 Spieler gelichzeitig Initialisieren
        switch(type[i]){

          case HUMAN :
           eingabe.setTextEingabe(!Args.isGUI());
           p[i] = new Spieler(eingabe);
           Delay[i]=-1;
          break;

          case RANDOM_AI :
           p[i]= new Computerspieler();
          break;

          case ADVANCED_AI_1 :
          p[i] = new AIspieler();
          break;

          case REMOTE :
            try{
              if(!Args.isOffer()){  // kein Offer = hosting the game
                // Registry registry=LocateRegistry.getRegistry("localhost",1099);
                switch(Args.getTypRemote()){
                  case HUMAN :
                   eingabe.setTextEingabe(!Args.isGUI());
                   p[i] = new Spieler(eingabe);
                  break;

                  case RANDOM_AI :
                   p[i]= new Computerspieler();
                  break;

                  case ADVANCED_AI_1 :
                  p[i] = new AIspieler();
                  break;
                }

                p[(i+1)%2] =find("localhost","RemotePlayer");

             try{
               if(i==0){ // get Blue or Red
                 p[i].init(Args.getSize(),PlayerColor.Red);
                 p[(i+1)%2].init(Args.getSize(),PlayerColor.Blue);
               }else{
                 p[i].init(Args.getSize(),PlayerColor.Blue);
                 p[(i+1)%2].init(Args.getSize(),PlayerColor.Red);
               }
             } catch (Exception e){
               // System.out.println("Exception vom Initialisieren des Remot-Spielers");
               // e.printStackTrace();
             }

             player1 = p[0];
             player2 = p[1];

             return;
           }
         }catch(Exception e){
           System.out.println("Exception beim Setting Remote-Spieler");
           e.printStackTrace();
         }

        }
      }
      try{
        if(i==0)
          p[i].init(Args.getSize(),PlayerColor.Red);
        else
          p[i].init(Args.getSize(),PlayerColor.Blue);
      } catch (Exception e){
        // System.out.println("Exception vom Initialisieren des Spielers");
        // e.printStackTrace();
      }
      try{
        if(Delay[i]==0)
          Delay[i] = ArgsParser.getDelay();
        else Delay[i] = 0;
      }catch (Exception e){ Delay[i]=0;}
    }

    player1 = p[0];
    player2 = p[1];
    DELAY1 = Delay[0];
    DELAY2 = Delay[1];
  }

//===================================================================================
/**
 * [offering wenn es isOffer, wird diese Methode aufgeruft,
 * erzeugt einen passenden Spieler, und liefert den Spieler Object zu Localhost]
 * @param Args [ArgumentParser, der alle Parameter gespeichert hat]
 * @param eingabe EIngabe-Methode
 */
  public void offering(Eingabe eingabe,ArgumentParser Args){
    // PlayerType type = null;
    Player p = null;
    Player pl=null;

    // try{
    //   type = Args.getRed();
    // }catch (Exception e){} //falls Leer heisst Remote-Spieler


    try{

      Registry registry=LocateRegistry.createRegistry(1099);

      switch(Args.getTypRemote()){
        case HUMAN :
        break;

        case RANDOM_AI :
         pl= new Computerspieler();
        break;

        case ADVANCED_AI_1 :
         pl = new AIspieler();
        break;

      }
      p = new Netzwerkspieler1(pl);
    }catch(Exception e) {
      e.printStackTrace();
    }
    // p = new Netzwerkspieler1(pl);
    offer(p,"localhost","RemotePlayer");
try{
    if(Args.getTypRemote()==PlayerType.HUMAN){
      PlayerType[] type = new PlayerType[]{null,null};
      try{
        type[0] = Args.getRed();
      }catch (Exception e){} //falls Leer heisst Remote-Spieler
      try{
        type[1] = Args.getBlue();
      }catch (Exception e){}

      boolean isRed=true;
      if(type[0]==null) isRed=false;
      System.out.println(isRed);

      SIZE = Args.getSize();
      board = new SWRBoard (SIZE);
      gui = new GUI(board.viewer(),Args.isGUI());
      gui.update(board.viewer());
      eingabe.setGui(gui);
      eingabe.setTextEingabe(!Args.isGUI());
      Spieler pm  = new Spieler(eingabe);
      // pm.init(SIZE,PlayerColor.Red);
      Netzwerkspieler1 pp = new Netzwerkspieler1(pm);
      pp.init(SIZE,(isRed)?PlayerColor.Red:PlayerColor.Blue);
      offer(pp,"localhost","RemotePlayer");
      ArrayList<Flower> m1= new ArrayList<Flower>();
      ArrayList<Flower> m1n= new ArrayList<Flower>();
      ArrayList<Ditch> d1= new ArrayList<Ditch>();
      ArrayList<Ditch> d1n= new ArrayList<Ditch>();
      Status status = Status.Ok;
        while (status == Status.Ok){
          Thread.sleep(1000);
          board=pp.getBoard();
          status=board.getStatus();
          gui.update(board.viewer());
          m1n.addAll(board.getFlowers((!isRed)?PlayerColor.Red:PlayerColor.Blue));
          m1n.removeAll(m1);
          m1.addAll(board.getFlowers((!isRed)?PlayerColor.Red:PlayerColor.Blue));
          d1n.addAll(board.getDitches((!isRed)?PlayerColor.Red:PlayerColor.Blue));
          d1n.removeAll(d1);
          d1.addAll(board.getDitches((!isRed)?PlayerColor.Red:PlayerColor.Blue));
          if (!m1n.isEmpty()) {
            Flower f = m1n.get(0);
            m1n.remove(f);
            Flower ff =m1n.get(0);
            m1n.remove(ff);
            Move m = new Move(f,ff);
            if(debug) System.out.println(m+"Status:"+status);

            gui.paintthis(m,isRed);
          }
          if (!d1n.isEmpty()) {
            Ditch d = d1n.get(0);
            d1n.remove(d);

            Move m = new Move(d);
            if(debug) System.out.println(m+"Status:"+status);

            gui.paintthis(m,isRed);
          }
          gui.update(board.viewer());
        }
      }
    }catch(Exception e){e.printStackTrace();}
  }
//===================================================================================
/**
 * [offer liefert den Spiler zu Host]
 * @param p    [Spieler-Object, der geliefert wird]
 * @param host [Name von Host]
 * @param name [Name von Spieler]
 */
  public void offer(Player p,String host, String name){
    try{
      Naming.rebind("rmi://" + host + "/" + name, p);
      System.out.println("Player (" + name +") ready");
    }catch(MalformedURLException ex){
      ex.printStackTrace();
    }catch(RemoteException ex){
      ex.printStackTrace();
    }
  }

//===================================================================================
/**
 * [find sucht den von Host]
 * @param  host [Name von Host]
 * @param  name [Name von Spieler]
 * @return      [geben den Spieler zurück]
 */
  public Player find(String host,String name){
    Player p=null;
    try{
      p=(Player)Naming.lookup("rmi://" + host + "/" +name);
      System.out.println("Player (" + name + ") found");
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return p;
  }
//===================================================================================
/**
 * [operate ist der Lauf vom Spiel, Player1 und Player2 tun etw nacheinander
 * bis zum Ende des Spiels]
 */
  public void operate(){
    Move move = null;
    Status status = Status.Ok;

    try{
// Pruefen ********************************************************************
      while (status == Status.Ok){
// P1 request *****************************************************************
        move = player1.request();
        gui.display(move);
        board.make(move);
// P1 confirm *****************************************************************
        status=board.getStatus();
        player1.confirm(status);

        makeDelay(player1,DELAY1);
// Ausgabe+Pruefen ************************************************************
        if(debug) System.out.println("Player Red :"+move+'\n'+"Status:"+status);
        gui.update(board.viewer());
        if(status != Status.Ok) break;
// P2 update ******************************************************************
        player2.update(move,status);
// P2 request******************************************************************
        move=player2.request();
        gui.display(move);
        board.make(move);
// P2 confirm *****************************************************************
        status=board.getStatus();
        player2.confirm(status);

        makeDelay(player2,DELAY2);
// Ausgabe+Pruefen ************************************************************
        if(debug) System.out.println("Play Blue :"+move+'\n'+"Status:"+status);
        gui.update(board.viewer());
        if(status != Status.Ok) break;
// P1 update ******************************************************************
        player1.update(move,status);

      }//End While

    }catch(Exception e){
        System.out.println("Widersprüche zwischen dem Status des eigenen Spielbretts"+
                              " und dem Status des Spielbretts des Hauptprogramms");
        e.printStackTrace();
    }
// END ******************************************************************
    System.out.println(status);
    System.out.println("Player Red:  "+board.getPoints(PlayerColor.Red));
    System.out.println("Player Blue: "+board.getPoints(PlayerColor.Blue));
  }
//===================================================================================
/**
 * [makeDelay wenn getPossibleMove nicht soviel (zB.<10000), dann spielt Computer extrem schnell,
 * wenn mit parameter -dalay eingegeben, bekommen wir ein Delay,
 * Delay für Human-Spieler ist immer O]
 * @param p [Player, der DELAY bekommt]
 * @param d [die Zeit, wie lange DELAY ist]
 */
public void makeDelay(Player p,int d){
  try{
    // if(p.getSize()<10000){
      Thread.sleep(d);
    // }
  }catch (Exception e){
    System.out.println("Cannot wait");
    e.printStackTrace();
  }
}
//===================================================================================

}//END SFW64
