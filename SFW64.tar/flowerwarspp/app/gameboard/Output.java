package app.gameboard;
import flowerwarspp.preset.*;
import app.superflowerwars64.*;
/**
 * Die Schnittstellle Output enthaelt die Methoden, die man fuer
 * eine einfache graphische Ausgabe braucht
 * @author Viktoriya Pak
 */
public interface Output {
	/**
	 * Setzt ein {@link MyViewer}-Objekt
	 * @param myViewer {@link MyViewer}
	 */
	void setMyViewer(MyViewer myViewer);
	/**
     * Foerdert die Bearbeitung und graphische Ausgabe des zuletzt gemachten Zuges
     * @param lastMove Der Spielzug, der zuletzt gemacht wurde
     */
	void display(Move lastMove);
}
