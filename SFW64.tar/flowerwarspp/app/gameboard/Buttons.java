package app.gameboard;
import flowerwarspp.preset.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.imageio.ImageIO;
import java.awt.image.*;

/**
    * Die Klasse Buttons ist fuer das Erzeugen zweier Buttons und fuer die Bearbeitung
    * der Ereignisse dieser Buttons
    * @author Viktoriya Pak
*/

public class Buttons extends JPanel {
    /**
     * Instanz von {@link GameboardGUI}
     */
    private GameboardGUI gGUI;
    /**
        * Ein Zug vom Typ {@link MoveType#Surrender}
    */
    private Move giveUpMove;
    /**
        * Ein Zug vom Typ {@link MoveType#End}
    */
    private Move endGameMove;

    /** Serialisierungskonstante */
    private static final long serialVersionUID = 1L;

    /**
        * Konstruktor der Klasse erzeugt zweu Buttons und enthaelt
        * {@link ActionListener} fuer jeden Button. Wenn ein Button
        * angecklickt wird, werdern die entsprechende Zuege erzeugt.
    */
    public Buttons(GameboardGUI gGUI) {
        this.gGUI = gGUI;
        setBackground(new Color(255,140,0));
        setLayout(new BorderLayout());
        JButton giveUpButton = new JButton("Give up");
        try {
            Image img = ImageIO.read(new File("aufgeben.png"));
            giveUpButton.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        giveUpButton.addActionListener(new ActionListener() {
           public void actionPerformed(ActionEvent e) {
               MoveType s = MoveType.Surrender;
               giveUpMove = new Move(s);
               gGUI.setNewMove(giveUpMove);
           }
        });
		giveUpButton.setToolTipText("You can give up if ....");
        JButton end = new JButton("End game");
        end.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (gGUI.getMyViewer().getPossibleMovesFl().size() == 0) {
                  MoveType s = MoveType.End;
                  endGameMove = new Move(s);
                  gGUI.setNewMove(endGameMove);
                  gGUI.handleLastMove(endGameMove);
                }
			}
		});
		end.setToolTipText("You can end game every time you want. The game will be then stopped and points will be computed");
        add(giveUpButton, BorderLayout.NORTH);
        add(Box.createRigidArea(new Dimension(5,5)), BorderLayout.CENTER);
        add(end, BorderLayout.SOUTH);
    }

    /**
        * Getter-Methode fuer {@link #giveUpMove}
    */

    public Move getGiveUpMove() {
        return giveUpMove;
    }

    /**
        * Getter-Methode fuer {@link #endGameMove}
    */

    public Move getEndGameMove() {
        return endGameMove;
    }
}
