package app.gameboard;

import flowerwarspp.preset.*;
import java.util.Scanner;

/**
 * Eingabe-Klasse bietet die Moeglichkeit entweder GUI-Eingabe oder Terminal-Text-Eingabe zu machen
 * @author Yufan.Dong
 */
public class Eingabe implements Requestable {
  /**graphical user interface*/
  private GUI gui;
  /**String speichert Terminal Text EINGABE*/
  private String text;
  /**gespeichert move*/
  private Move move;
  /** 0 = GUI-Eingabe, 1 = Terminal-Eingabe */
  private boolean isText;


  /**
   * [request liefert ein Move zurueck]
   * @return [Move {@link Move} von gewaehlter Eingabe-Methode]
   */
  public Move request(){
    if(isText){
      System.out.println("Your next Move:");
      Scanner scan = new Scanner(System.in);
      if(scan.hasNext()){
        text=scan.next();
      }
      move = Move.parseMove(text);
    } else{
      move = gui.request();
    }
    return move;
  }

  /**
   * [setTextEingabe ob setTextEingabe ist]
   * @param a [isText eingabe]
   */
  public void setTextEingabe(boolean a){
    isText = a;
  }
  /**
   * [setGui setzt gui mit theGUI]
   * @param theGUI [graphical user interface]
   */
  public void setGui(GUI theGUI){
    gui = theGUI;
  }

}
