package app.gameboard;
import flowerwarspp.preset.*;
import java.awt.*;
import javax.swing.*;
import java.io.*;
import java.util.*;
import javax.imageio.ImageIO;
import java.awt.image.*;
import java.awt.event.*;

/**
    * Die Klasse Scores repraesentiert eine Tabelle mit Punkten von Spielern und enthaelt
    * alle dau benoetigte Information
    * @author Viktoriya Pak
*/

public class Scores extends JPanel {
    /**
        * Die Punkte des roten Spielers
    */
    private int scoreRed = 0;
    /**
        * Die Punkte des blauen Spielers
    */
    private int scoreBlue = 0;

    /** Serialisierungskonstante */
    private static final long serialVersionUID = 1L;

    /**
        * Setter-Methode fuer {@link #scoreRed}
    */
    public void setScoreRed(int sc) {
        scoreRed = sc;
    }

    /**
        * Setter-Methode fuer {@link #scoreBlue}
    */
    public void setScoreBlue (int sc) {
        scoreBlue = sc;
    }
    /**
        * Konstruktor der Klasse erzeugt eine graphische Darstellung der Tabelle und
        * gibt die Punkte beider Spieler aus
        * @throws IOException Wenn das Bild fuer die Tabelle nicht vorhanden ist
    */
    public Scores() {
          Graphics g = getGraphics();
        try {
            BufferedImage redPic = ImageIO.read(new File("red.png"));
            BufferedImage bluePic = ImageIO.read(new File("blue.png"));
            JLabel redPicLabel = new JLabel(new ImageIcon(redPic));
            JLabel bluePicLabel = new JLabel(new ImageIcon(bluePic));
            add(redPicLabel);
            add(bluePicLabel);
        } catch(IOException e) {
            e.printStackTrace();
        }
    }
}
