package app.gameboard;

import flowerwarspp.preset.*;

public class Eingabe implements Requestable {

  private GameboardGUI gui;

  private String text;

  private Move move;
  /** 0 = GUI-Eingabe, 1 = Terminal-Eingabe */
  private boolean isText;

  /**
   * [request liefert ein Move zurück]
   * @return [Move von gewählter Eingabe-Methode]
   */
  public Move request(){
    if(isText){
      move = Move.parseMove(text);
    } else{
      move = gui.request();
    }
    return move;
  }

  public void textEingabe(boolean a){
    isText = a;
  }

  public void setMove(String move){
    text = move;
  }

  public void mouseMove(GameboardGUI theGUI){
    gui = theGUI;
  }

}
