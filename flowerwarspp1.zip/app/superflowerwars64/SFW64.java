package app.superflowerwars64;

import app.player.*;
import app.gameboard.*;
import flowerwarspp.preset.*;
import java.net.*;
import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;

/**
 * main class
 * !!!!!!!!!!!!! Eingabe: Einleitung !!!!!!!!!!
 * Nomal Spiel:                -red tt -blue tt -size xx (--gui) (-delay xx)
 * Remote Offer:   entweder   -red remote -typRemote tt -size xx --offer        oder    -blue remote -typRemote tt -size xx --offer
 * Remote Finder:  entweder   -blue remote -typRemote tt -size xx               oder    -red remote -typRemote tt -size xx
 * tt kann nur (human,random oder adv1) seinen
 * xx sollte int-Zahl sein
 * () ist eine optional-Eingabe: (--gui) bietet GUI-eingabe wenn es Human-spiler gibt
 * in build.xml sind alle vorhand, außer, für Flag(--gui,--offer) muss ein MinusZeichen(-) hizufuegen
 */
public class SFW64 {

  private SWRBoard board;
  private Player player1;
  private Player player2;
  private Eingabe eingabe = new Eingabe();
  private ArgumentParser ArgsParser;

	private GUI gui=null;
  private int SIZE;
  private int DELAY1=0;
  private int DELAY2=0;

//===================================================================================
  public static void main (String[] args) throws ArgumentParserException{
    SFW64 flowerwar=new SFW64();
    flowerwar.init(args);
    //wenn das nicht Offer ist, also wenn es "hosting the game", wird weiter operate()
    if(!flowerwar.ArgsParser.isOffer()){
      flowerwar.operate();
    }
  }

//===================================================================================
  public void init(String[] args) throws ArgumentParserException{

    ArgsParser = new ArgumentParser(args);
    if(!ArgsParser.isOffer()){

      SIZE = ArgsParser.getSize();
      //mit GUI EINGABE ODER NICHT
      boolean isGUI = ArgsParser.isGUI();

      board = new SWRBoard (SIZE);
      gui = new GUI(board.viewer(),isGUI);
      gui.update(board.viewer());
      eingabe.setGui(gui);

      setPlayer(eingabe,ArgsParser);

    }else offering(ArgsParser);
  }

//===================================================================================
  public void setPlayer(Eingabe eingabe, ArgumentParser Args)throws ArgumentParserException {
    Player[] p = new Player[2];
    int[] Delay = new int[2];

    PlayerType[] type = new PlayerType[]{null,null};
    try{
      type[0] = Args.getRed();
    }catch (Exception e){} //falls Leer heisst Remote-Spieler
    try{
      type[1] = Args.getBlue();
    }catch (Exception e){}

    for(int i = 0; i < 2; i++){
      if(type[i]!=null){ //falls null -> i++ -> case: Remote -> 2 Spieler gelichzeitig Initialisieren
        switch(type[i]){

          case HUMAN :
           eingabe.setTextEingabe(!Args.isGUI());
           p[i] = new Spieler(eingabe);
           Delay[i]=-1;
          break;

          case RANDOM_AI :
           p[i]= new Computerspieler();
          break;

          case ADVANCED_AI_1 :
          p[i] = new AIspieler();
          break;

          case REMOTE :
            try{
              if(!Args.isOffer()){  // kein Offer = hosting the game
                Registry registry=LocateRegistry.getRegistry("localhost",1099);
                switch(Args.getTypRemote()){
                  case HUMAN :
                   eingabe.setTextEingabe(!Args.isGUI());
                   p[i] = new Spieler(eingabe);
                  break;

                  case RANDOM_AI :
                   p[i]= new Computerspieler();
                  break;

                  case ADVANCED_AI_1 :
                  p[i] = new AIspieler();
                  break;
                }

                p[(i+1)%2] =find("localhost","DummyPlayer");

             try{
               if(i==0){ // get Blue or Red
                 p[i].init(Args.getSize(),PlayerColor.Red);
                 p[(i+1)%2].init(Args.getSize(),PlayerColor.Blue);
               }else{
                 p[i].init(Args.getSize(),PlayerColor.Blue);
                 p[(i+1)%2].init(Args.getSize(),PlayerColor.Red);
               }
             } catch (Exception e){
               // System.out.println("Exception vom Initialisieren des Remot-Spielers");
               // e.printStackTrace();
             }

             player1 = p[0];
             player2 = p[1];

             return;
           }
         }catch(Exception e){
           System.out.println("Exception beim Setting Remote-Spieler");
           e.printStackTrace();
         }


          default :
            System.out.println("Unsupported player type: "  + type);
          break;
        }
      }
      try{
        if(i==0)
          p[i].init(Args.getSize(),PlayerColor.Red);
        else
          p[i].init(Args.getSize(),PlayerColor.Blue);
      } catch (Exception e){
        // System.out.println("Exception vom Initialisieren des Spielers");
        // e.printStackTrace();
      }
      try{
        if(Delay[i]==0)
          Delay[i] = ArgsParser.getDelay();
        else Delay[i] = 0;
      }catch (Exception e){ Delay[i]=0;}
    }

    player1 = p[0];
    player2 = p[1];
    DELAY1 = Delay[0];
    DELAY2 = Delay[1];
  }

//===================================================================================
  public void offering(ArgumentParser Args){
    PlayerType type = null;
    Player pl=null;

    try{
      type = Args.getRed();
    }catch (Exception e){} //falls Leer heisst Remote-Spieler


    try{

      Registry registry=LocateRegistry.createRegistry(1099);

      switch(Args.getTypRemote()){
        case HUMAN :
         eingabe.setTextEingabe(!Args.isGUI());
         pl = new Spieler(eingabe);
        break;

        case RANDOM_AI :
         pl= new Computerspieler();
        break;

        case ADVANCED_AI_1 :
         pl = new AIspieler();
        break;

        default:
         System.out.println("Unsupported player type: "  + type);
        break;
      }

      if (type!=null)
        pl.init(Args.getSize(),PlayerColor.Red);
      else
        pl.init(Args.getSize(),PlayerColor.Blue);


      Player p = new Netzwerkspieler1(pl);
      // p.init(Args.getSize(),);
      offer(p,"localhost","DummyPlayer");

    }catch(Exception e) {
      e.printStackTrace();
    }

  }
//===================================================================================
  public void offer(Player p,String host, String name){
    try{
      Naming.rebind("rmi://" + host + "/" + name, p);
      System.out.println("Player (" + name +") ready");
    }catch(MalformedURLException ex){
      ex.printStackTrace();
    }catch(RemoteException ex){
      ex.printStackTrace();
    }
  }

//===================================================================================
  public Player find(String host,String name){
    Player p=null;
    try{
      p=(Player)Naming.lookup("rmi://" + host + "/" +name);
      System.out.println("Player (" + name + ") found");
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return p;
  }
//===================================================================================
/**
 * [operate ist der Lauf vom Spiel, Player1 und Player2 tun etw nacheinander
 * bis zum Ende des Spiels]
 */
  public void operate(){
    Move move = null;
    Status status = Status.Ok;

    try{
// Pruefen ********************************************************************
      while (status == Status.Ok){
// P1 request *****************************************************************
        move = player1.request();
        gui.display(move);
        board.make(move);
// P1 confirm *****************************************************************
        status=board.getStatus();
        player1.confirm(status);

        makeDelay(player1,DELAY1);
// Ausgabe+Pruefen ************************************************************
        System.out.println("Player Red :"+move);
        gui.update(board.viewer());
        if(status != Status.Ok) break;
// P2 update ******************************************************************
        player2.update(move,status);
// P2 request******************************************************************
        move=player2.request();
        gui.display(move);
        board.make(move);
// P2 confirm *****************************************************************
        status=board.getStatus();
        player2.confirm(status);

        makeDelay(player2,DELAY2);
// Ausgabe+Pruefen ************************************************************
        System.out.println("Play Blue :"+move);
        gui.update(board.viewer());
        if(status != Status.Ok) break;
// P1 update ******************************************************************
        player1.update(move,status);

      }//End While

    }catch(Exception e){
        System.out.println("Widersprüche zwischen dem Status des eigenen Spielbretts"+
                              " und dem Status des Spielbretts des Hauptprogramms");
        e.printStackTrace();
    }
// END ******************************************************************
    System.out.println(status);
    System.out.println("Player Red:  "+board.getPoints(PlayerColor.Red));
    System.out.println("Player Blue: "+board.getPoints(PlayerColor.Blue));
  }
//===================================================================================
/**
 * [makeDelay wenn getPossibleMove nicht soviel (zB.<10000), dann spielt Computer extrem schnell,
 * wenn mit parameter -dalay eingegeben, bekommen wir ein Delay,
 * Delay für Human-Spieler ist immer O]
 * @param p [Player, der DELAY bekommt]
 * @param d [die Zeit, wie lange DELAY ist]
 */
public void makeDelay(Player p,int d){
  try{
    if(p.getSize()<10000){
      Thread.sleep(d);
    }
  }catch (Exception e){
    System.out.println("Cannot wait");
    e.printStackTrace();
  }
}
//===================================================================================

}//END SFW64
