package flowerwarspp.preset;

import java.io.*;

/**
 * Diese Enumeration enthaelt die beiden Spielerfarben Rot und Blau.
 *
 * @author Dominick Leppich
 */
public enum PlayerColor implements Serializable {
    Red,
    Blue
}
