package app.gameboard;
import flowerwarspp.preset.*;
import app.superflowerwars64.*;

public interface Output {
	void setMyViewer(MyViewer myViewer);
	void display(int size);
}
