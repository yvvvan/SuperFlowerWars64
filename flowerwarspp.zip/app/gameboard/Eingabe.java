package app.gameboard;

import flowerwarspp.preset.*;

public class Eingabe implements Requestable {
  private GameboardGUI gui;

  public Move request(){
    return gui.request();
  }
}
