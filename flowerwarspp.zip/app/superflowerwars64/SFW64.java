package app.superflowerwars64;

import app.player.*;
import app.gameboard.*;
import flowerwarspp.preset.*;
import java.net.*;
import java.rmi.*;


public class SFW64 {

      // public void initPlayer(SP,NET){
      //   switch(SP){
      //     case 1: Spieler         player = new Spieler(eingabe1);                     break;
      //     case 2: Computerspieler player = new Computerpieler(eingabe1);              break;
      //     case 3: AIspieler       player = new AIspieler(eingabe1);                   break;
      //     case 4: Netzwerkspieler1 player= new Netzwerkspieler1(initPlayer(NET));    break;
      //     default:System.out.println("Falsche eingabe1");  System.exit(0);   break;
      //   }
      // }
      //

      private SWRBoard board;
      private Player player1 = null;
      private Player player2 = null;
      private Eingabe eingabe1;
      private Eingabe eingabe2;

      // private Requestable myeingabe1;
      // private Requestable myeingabe2;
	    // private Output output1;
	    // private Output output2;
	    //
	    private GameboardGUI gui;


      public void offer(Player p,String host, String name){
        try{
          Naming.rebind("rmi://" + host + "/" + name, p);
          System.out.println("Player (" + name +") ready");
        }catch(MalformedURLException ex){
          ex.printStackTrace();
        }catch(RemoteException ex){
          ex.printStackTrace();
        }
      }

      public Player find(String host,String name){
        Player p=null;
        try{
          p=(Player)Naming.lookup("rmi://" + host + "/" +name);
          System.out.println("Player (" + name + ") found");
        }catch(Exception ex){
          ex.printStackTrace();
        }
        return p;
      }

      public void operate(){
        Move move=null;
        Status status =Status.Ok;
        try{
          while (status != Status.Illegal){
            move=player1.request();
            board.make(move);
            status=board.getStatus();
            player1.confirm(status);
            player2.update(move,status);
            move=player2.request();
            board.make(move);
            status=board.getStatus();
            player2.confirm(status);
            player1.update(move,status);
          }
        }catch(Exception e){
            System.out.println("Widersprüche zwischen dem Status des eigenen Spielbretts und dem Status des Spielbretts des Hauptprogramms");
            e.printStackTrace();
        }
      }

      public static void main(String[] args){
        SFW64 flowerwar=new SFW64();
        // System.out.println("Bitte geben die Spieler Klassen und die Größe des Spielbretts ein(mit Leerzeichen). \n Rote Blaue Größe");
        // System.out.println("Mögliche Spieler-Klasse: 1 - Normale Spieler; 2 - RandomComputerSpieler; 3 - AIComputerSpieler; 4 - Netzwerkspieler"); // zB. 9 3 1 Offer NetSP1 NetSP2
        flowerwar.init(args);
        flowerwar.operate();
      }

      public void getColored(int a, int size, Player p1, Player p2){
        try{  switch (a){
          case 0:
            p1.init(size, PlayerColor.Red);
            p2.init(size, PlayerColor.Blue);
            break;
          case 1:
            p2.init(size, PlayerColor.Red);
            p1.init(size, PlayerColor.Blue);
            break;
              }
        }catch(Exception e){
            System.out.println("Exception");
            e.printStackTrace();
        }
      }

      public void init(String[] args) { // args: spieler1 spierl2 groesse

        final int COLOR = Integer.parseInt(args[0]);

        final int SIZE = Integer.parseInt(args[1]);

        final int isLocal = Integer.parseInt(args[2]); //0->Online 1->Local

        final int isOffer;

        final int SP1;
        final int SP2;

        if (isLocal == 0) {
          isOffer = Integer.parseInt(args[3]);
          if(isOffer == 0){ //0->Find 1->offer
            player1 = find("localhost","flowerwar");
            SP1 = Integer.parseInt(args[4]);
            switch (SP1){
              case 1: player2 = new Spieler(eingabe1);             break;
              case 2: player2 = new Computerspieler();      break;
              case 3: player2 = new AIspieler();           break;
            }
          }
          else {//isOffer == 1
            SP1 = Integer.parseInt(args[4]);
            switch (SP1){
              case 1: player1 = new Spieler(eingabe2);             break;
              case 2: player1 = new Computerspieler();      break;
              case 3: player1 = new AIspieler();           break;
            }
            try{Player p = new Netzwerkspieler1(player1);offer(p,"localhost","flowerwar");}
            catch(RemoteException e){
                System.out.println("RemoteException");
                e.printStackTrace();
            }

          }
        }
        else  {
          SP1 = Integer.parseInt(args[3]);
          switch (SP1){
            case 1: player1 = new Spieler(eingabe1);             break;
            case 2: player1 = new Computerspieler();      break;
            case 3: player1 = new AIspieler();           break;
          }
          SP2 = Integer.parseInt(args[4]);
          switch (SP2){
            case 1: player2 = new Spieler(eingabe2);             break;
            case 2: player2 = new Computerspieler();      break;
            case 3: player2 = new AIspieler();           break;
          }
        }
        getColored(COLOR,SIZE,player1,player2);

        board = new SWRBoard(SIZE);

        if(isLocal==1){
          switch (SP1){
            case 1:
          }
        }
    }
}
