package app.gameboard;

import flowerwarspp.preset.*;
import java.util.Scanner;

public class Eingabe implements Requestable {

  private GUI gui;

  private String text;

  private Move move;
  /** 0 = GUI-Eingabe, 1 = Terminal-Eingabe */
  private boolean isText;

  /**
   * [request liefert ein Move zurück]
   * @return [Move von gewählter Eingabe-Methode]
   */
  public Move request(){
    if(isText){
      System.out.println("Your next Move:");
      Scanner scan = new Scanner(System.in);
      if(scan.hasNext()){
        text=scan.next();
      }
      move = Move.parseMove(text);
    } else{
      // System.out.println("okok");
      move = gui.request();
      // System.out.println(move.getType());
    }
    return move;
  }

  public void setTextEingabe(boolean a){
    isText = a;
  }

  public void setGui(GUI theGUI){
    gui = theGUI;
  }

}
